import React from "react"
import {Link} from 'react-router-dom';


function Third_page(){
	return(
		<div>
			<h1> Where do we get the news? third page </h1>
		</div>
	);
}

export default Third_page;